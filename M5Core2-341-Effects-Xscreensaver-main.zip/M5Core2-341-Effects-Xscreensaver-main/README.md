# 341 Effects Screensaver - M5Stack Core2 Port

Ultimate M5Stack Core2 Screensaver Collection featuring 341 stunning visual effects including Plasma, Fractals, Particle Systems, 3D Simulations, Geometric Patterns, Abstract Animations, and Classic Screensaver Effects.

## 🎨 Features

- **341 Visual Effects** - Massive collection of eye-catching screensavers
- **Core2 Optimized** - Ported from Core1 with full Core2 compatibility
- **Touch Interface** - Native Core2 touch button support
- **High Performance** - Smooth 60fps animations on 320x240 display
- **Easy Navigation** - Simple button controls for effect switching
- **Auto-scroll Mode** - Hands-free continuous effect cycling

## 🎮 Controls

- **Button A** - Next effect
- **Button B** - Previous effect  
- **Button C Hold** - Enable/disable auto-scroll mode
- **Touch Buttons** - Full Core2 capacitive touch support

## 🚀 Quick Start

### M5Burner Installation
1. Download `M5Core2_341Effects_v1.0_MERGED.bin` and `M5Core2_341Effects_v1.0_MERGED.json`
2. Open M5Burner
3. Load the JSON file to install the screensaver
4. Flash to your M5Stack Core2

### Build from Source
```bash
# Clone repository
git clone <repository-url>
cd 341Core2

# Build and upload
platformio run --target upload
```

## 📋 Requirements

- **Hardware**: M5Stack Core2
- **Platform**: PlatformIO
- **Framework**: Arduino
- **Library**: M5Core2 (^0.1.9)

## 🔧 Technical Details

- **Memory Usage**: 1.4% RAM, 11.8% Flash (773KB)
- **Effects**: 341 unique visual algorithms
- **Resolution**: 320x240 pixels
- **Frame Rate**: Up to 60 FPS
- **Compatibility**: ESP32-based M5Stack Core2

## 🎯 Conversion Notes

This project was successfully ported from M5Stack Core1 with minimal code changes:
- Changed include from `<M5Stack.h>` to `<M5Core2.h>`
- Updated board configuration to `m5stack-core2`
- **Result**: 100% compatibility with enhanced touch features!

## 📦 Files

- `src/main.cpp` - Main application with 341 visual effects
- `platformio.ini` - Build configuration
- `M5Core2_341Effects_v1.0_MERGED.bin` - Ready-to-flash binary
- `M5Core2_341Effects_v1.0_MERGED.json` - M5Burner metadata

## 🎨 Effect Categories

- **Plasma Effects** - Colorful flowing plasma animations
- **Fractal Patterns** - Mathematical fractal visualizations  
- **Particle Systems** - Dynamic particle simulations
- **3D Simulations** - Pseudo-3D geometric animations
- **Abstract Art** - Artistic algorithmic patterns
- **Classic Screensavers** - Retro computer screensaver effects
- **Geometric Patterns** - Mathematical shape animations

## 🌟 Highlights

- **First-ever** 341 Effects collection for M5Stack Core2
- **Seamless port** from Core1 architecture
- **Touch-optimized** interface design
- **Professional quality** visual effects
- **Open source** and fully customizable

## 🛠️ Development

Built with PlatformIO using the M5Core2 library. The compatibility layer allows all original effects to work unchanged on Core2 hardware.

### Build Requirements
```ini
platform = espressif32
board = m5stack-core2  
framework = arduino
lib_deps = m5stack/M5Core2@^0.1.9
```

## 📊 Statistics

- **Source Code**: ~24,000 lines
- **Build Time**: ~42 seconds
- **Binary Size**: 839KB (merged with bootloader)
- **Effects Count**: 341 unique animations
- **Tested**: ✅ Core2 hardware verified

## 🏆 Achievement

This project demonstrates the excellent compatibility between M5Stack Core1 and Core2 platforms, proving that complex visual applications can be ported with virtually zero code changes.

## 📄 License

License & Attribution
This project ports effects originally from XScreensaver by Jamie Zawinski and contributors. The XScreensaver license permits modification and distribution for non-Windows platforms.

Original XScreensaver: https://www.jwz.org/xscreensaver/
License: MIT-compatible (no Windows restriction clause applies)

## 👨‍💻 Author

**CoreyMillia** - M5Stack enthusiast and visual effects developer

---

*Experience 341 stunning visual effects on your M5Stack Core2! Perfect for ambient displays, demonstrations, or just enjoying beautiful algorithmic art.*
